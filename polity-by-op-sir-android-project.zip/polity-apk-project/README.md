# Polity by OP Sir — Android APK project

This Android project wraps the live Polity by OP Sir website in a native Android WebView.

Website: https://polity-by-op-sir-uyi09d.v2.appdeploy.ai/

Build with Android Studio or a machine with the Android SDK and Gradle. The resulting APK can then be hosted on the website for direct download.
